#!/bin/sh

sh /koolshare/aria2/aria2_run.sh stop
rm -rf /koolshare/aria2
rm -rf /koolshare/perp/aria2
rm -rf /koolshare/scripts/aria2_config.sh
rm -rf /koolshare/scripts/aria2_status.sh
rm -rf /koolshare/res/aria2_check.html
rm -rf /koolshare/res/icon-aria2.png
rm -rf /koolshare/webs/Module_aria2.asp
rm -fr /koolshare/scripts/uninstall_aria2.sh
